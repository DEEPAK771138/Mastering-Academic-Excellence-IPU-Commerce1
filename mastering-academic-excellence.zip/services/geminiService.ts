import { GoogleGenAI } from "@google/genai";
import { SubjectId, ContentType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getSystemInstruction = (subjectId: SubjectId) => {
  const baseInstruction = `
    You are the "Mastering Academic Excellence" engine, the most advanced AI tutor for the Karnataka Pre-University (PU) Board, specifically for 1st PUC Commerce stream.
    
    MISSION: 
    Help the student achieve 100/100 marks. Your content must be elusive, elaborate, and rigorous.
    
    CRITICAL PROTOCOLS:
    1. STRICTLY ADHERE to the latest Karnataka PU Board Blueprint and Syllabus (2024-25).
    2. CONSULT the "Scheme of Valuation" implicitly for every answer. Use the exact keywords evaluators look for.
    3. FORMATTING: 
       - Use Markdown. 
       - Use Tables for differences. 
       - Use Bold for key terms. 
       - Use Blockquotes (>) for definitions, "Key Valuation Terms", "Common Mistakes", or "Evaluator Notes".
       - Use Code Blocks (\`\`\`language) for Computer Science.
    4. TONE: Scholarly, Authoritative, and Motivating.
  `;

  if (subjectId === SubjectId.KANNADA) {
    return baseInstruction + `
      IMPORTANT: The output MUST be in KANNADA Language (Kannada Script).
      Ensure high literary standard suitable for 1st PU Kannada Sahitya (Sahitya Sallapa).
    `;
  }

  return baseInstruction;
};

export const fetchStudyContent = async (
  subjectId: SubjectId,
  subjectName: string,
  chapterTitle: string,
  contentType: ContentType,
  onStreamUpdate?: (text: string) => void
): Promise<string> => {
  const systemInstruction = getSystemInstruction(subjectId);
  const modelId = "gemini-2.5-flash"; 

  let prompt = "";

  switch (contentType) {
    case ContentType.CONCEPTS:
      prompt = `
        Consult the Karnataka PU Board syllabus for "${chapterTitle}" in ${subjectName}.
        Provide a comprehensive, chapter-wise concept guide.
        
        Strict Structure:
        1. **Glossary of Key Terms**: Identify and define 5-8 crucial terms/definitions for this chapter.
        2. **Core Concepts**: Detailed point-wise explanations of theories and principles.
        3. **Important Formulas/Diagrams**: (If applicable).
        4. **Common Student Mistakes**: A dedicated section highlighting 3-4 common misconceptions or errors students make in this chapter.
        5. **Summary**: A brief wrap-up.
      `;
      break;
    case ContentType.MCQ:
      prompt = `
        Generate a rigorous Objective Section for "${chapterTitle}" in ${subjectName}.
        Include:
        1. 15 High-Yield Multiple Choice Questions (MCQs) with options.
        2. 5 Fill in the Blanks.
        3. 5 Match the Following pairs.
        
        At the end, provide a clearly labeled 'ANSWER KEY & EXPLANATIONS'.
        Format the key as:
        1. [Option] - [Detailed reason why this option is correct]
        2. [Option] - [Detailed reason...]
      `;
      break;
    case ContentType.SHORT_ANSWERS:
      prompt = `
        Generate an 'Answer Bank' of Short Answer Questions for "${chapterTitle}" in ${subjectName}.
        Section A: 2-Mark Questions (Generate 5). Provide precise 2-3 sentence answers.
        Section B: 5-Mark Questions (Generate 5). Provide point-wise answers (min 10 points or 2 paragraphs).
        
        Format for each question:
        **Q:** [Question]
        **A:** [Answer]
        > **Key Valuation Terms:** [List 2-3 specific keywords evaluators look for]
        > **Common Mistake:** [Specific error students often make on this question]
      `;
      break;
    case ContentType.LONG_ANSWERS:
      prompt = `
        Generate 3 "Essay Type" or Long Answer Questions (8-10 marks) for "${chapterTitle}" in ${subjectName}.
        
        Structure for each Answer:
        ### Introduction
        [Brief context or definition]
        
        ### Body
        [Detailed explanation with clear Side-Headings for every point]
        
        ### Conclusion
        [Summary or closing thought]
        
        > **Evaluator's Note:** [Tip to score full marks, e.g., "Draw a diagram"]
        > **Common Mistake:** [What to avoid in this essay]
      `;
      break;
    case ContentType.PRACTICAL:
      prompt = `
        Create 2 complex Practical Oriented Questions (POQ) or Numerical Problems for "${chapterTitle}" in ${subjectName}.
        
        Instructions:
        - If Accountancy: Provide a complex problem (e.g., Financial Statements) and show the solution step-by-step with Working Notes in Tables.
        - If Computer Science: Provide a Code Snippet or Logic problem using strictly formatted Markdown code blocks (e.g., \`\`\`cpp). Add comments explaining the logic.
        - If Business/Economics: Provide a Case Study with questions and answers.
      `;
      break;
    case ContentType.PREVIOUS_PAPERS:
      prompt = `
        Generate a "Previous Year Solved Paper Questions" set for "${chapterTitle}" in ${subjectName}.
        
        Task:
        1. Identify 5 frequently asked questions from previous Karnataka 1st PU Board Exams.
        2. EXPLICITLY TAG each question with the Year (e.g., [March 2019]).
        3. Provide the 'Scheme of Valuation' style answer.
      `;
      break;
    case ContentType.TIPS:
      prompt = `
        Act as a Chief Evaluator. Provide "Answer Writing Tips" for "${chapterTitle}" in ${subjectName}.
        
        Structure:
        1. **Common Pitfalls**: What mistakes to avoid?
        2. **Scheme of Valuation Analysis**: How are marks split?
        3. **Time Management**: Specific to this chapter.
        4. **Golden Keywords**: List of words that impress evaluators.
      `;
      break;
    case ContentType.EXAM_SIMULATION:
      prompt = `
        Generate a "Mock Exam Question Paper" for "${chapterTitle}".
        Duration: 45 Minutes. Max Marks: 35.
        
        Strict Structure:
        
        # MOCK EXAM: ${chapterTitle}
        *(Time Allowed: 45 Mins | Max Marks: 35)*
        
        ## PART A: Objective (1 Mark each)
        1. [MCQ]
        2. [MCQ]
        3. [Fill in blank]
        4. [Match following]
        5. [One word answer]
        
        ## PART B: Short Answers (2 Marks each)
        6. [Question]
        7. [Question]
        8. [Question]
        
        ## PART C: Analytical Answers (5 Marks each)
        9. [Question]
        10. [Question]
        
        ## PART D: Long Answer (8 Marks)
        11. [Question]
        
        ---
        |||HIDDEN_SEPARATOR|||
        ---
        
        # ANSWER KEY & EVALUATION SCHEME
        (Only view after completing the test)
        
        [Provide detailed solutions for all questions above, allocated by marks]
        [For MCQs, include brief reasoning]
        
        IMPORTANT: Output the separator |||HIDDEN_SEPARATOR||| exactly as is on a new line. Do NOT wrap it in code blocks or other markdown.
      `;
      break;
  }

  try {
    const responseStream = await ai.models.generateContentStream({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.3,
      },
    });

    let fullText = "";
    for await (const chunk of responseStream) {
      if (chunk.text) {
        fullText += chunk.text;
        if (onStreamUpdate) {
          onStreamUpdate(fullText);
        }
      }
    }

    return fullText;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate content. Please try again.");
  }
};