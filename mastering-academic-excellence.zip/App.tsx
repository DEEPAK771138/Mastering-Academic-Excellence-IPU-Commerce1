import React, { useState } from 'react';
import Layout from './components/Layout';
import ChapterList from './components/ChapterList';
import ContentGenerator from './components/ContentGenerator';
import { Subject, Chapter } from './types';
import { SUBJECTS } from './constants';
import { 
  GraduationCap, 
  ArrowRight,
  Calculator,
  Briefcase,
  TrendingUp,
  Monitor,
  BookOpen,
  Feather
} from 'lucide-react';

const ICON_MAP: Record<string, React.ElementType> = {
  'calculator': Calculator,
  'briefcase': Briefcase,
  'trending-up': TrendingUp,
  'monitor': Monitor,
  'book-open': BookOpen,
  'feather': Feather
};

const App: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);

  const handleSubjectSelect = (subject: Subject) => {
    setSelectedSubject(subject);
    setSelectedChapter(null);
  };

  const handleChapterSelect = (chapter: Chapter) => {
    setSelectedChapter(chapter);
  };

  const handleBackToSubjects = () => {
    setSelectedSubject(null);
    setSelectedChapter(null);
  };

  const handleBackToChapters = () => {
    setSelectedChapter(null);
  };

  // View: Chapter Content
  if (selectedSubject && selectedChapter) {
    return (
        <ContentGenerator 
            subject={selectedSubject} 
            chapter={selectedChapter} 
            onBack={handleBackToChapters} 
        />
    );
  }

  // View: Chapter List
  if (selectedSubject) {
    return (
      <Layout title={selectedSubject.name}>
        <ChapterList 
          subject={selectedSubject} 
          onSelectChapter={handleChapterSelect} 
          onBack={handleBackToSubjects}
        />
      </Layout>
    );
  }

  // View: Subject Selection (Dashboard)
  return (
    <Layout title="Dashboard">
      <div className="p-6 md:p-12 max-w-7xl mx-auto animate-fade-in">
        <div className="text-center mb-16">
          <div className="inline-block p-4 rounded-full bg-slate-800 border-2 border-amber-500 mb-6 shadow-[0_0_20px_rgba(251,191,36,0.2)]">
            <GraduationCap className="w-16 h-16 text-amber-400" />
          </div>
          <h1 className="text-4xl md:text-6xl font-serif font-black text-slate-100 mb-4 tracking-tight">
            Mastering Academic Excellence
          </h1>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto font-light leading-relaxed">
            The ultimate exam-oriented platform for 1st PUC Commerce. 
            Detailed answers, model papers, and strict evaluation guides for the Karnataka Board.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SUBJECTS.map((subject) => {
            const SubjectIcon = ICON_MAP[subject.iconKey] || BookOpen;
            
            return (
              <button
                key={subject.id}
                onClick={() => handleSubjectSelect(subject)}
                className="group relative bg-[#1e293b] rounded-xl p-8 text-left border border-slate-700 hover:border-amber-400 transition-all duration-300 hover:shadow-2xl hover:shadow-amber-900/20 hover:-translate-y-2 flex flex-col justify-between h-64"
              >
                <div>
                  <div className="flex justify-between items-start mb-6">
                    <span className="text-slate-500 text-xs font-bold tracking-widest uppercase bg-slate-800 px-2 py-1 rounded">Code {subject.code}</span>
                    <div className={`p-2 rounded-lg bg-slate-800 border border-slate-700 group-hover:border-amber-400/50 transition-colors`}>
                      <SubjectIcon className={`w-6 h-6 ${subject.color}`} />
                    </div>
                  </div>
                  <h3 className={`text-3xl font-serif font-bold ${subject.color} mb-2`}>{subject.name}</h3>
                  <p className="text-slate-400 text-sm">
                    {subject.chapters.length} Chapters • Syllabus 2024-25
                  </p>
                </div>
                
                <div className="flex items-center text-slate-300 group-hover:text-amber-400 transition-colors font-medium">
                  <span>Start Studying</span>
                  <ArrowRight className="ml-2 w-4 h-4 transform group-hover:translate-x-2 transition-transform" />
                </div>
                
                {/* Decorative gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-transparent to-black/20 rounded-xl pointer-events-none" />
              </button>
            );
          })}
        </div>
        
        <footer className="mt-20 text-center text-slate-600 text-sm">
           <p>© 2024 Mastering Academic Excellence. Designed for Karnataka PU Board Students.</p>
        </footer>
      </div>
    </Layout>
  );
};

export default App;