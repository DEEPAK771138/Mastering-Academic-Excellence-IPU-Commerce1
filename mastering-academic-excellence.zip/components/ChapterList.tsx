import React from 'react';
import { Subject, Chapter } from '../types';
import { Book, ChevronRight, Calculator, Briefcase, TrendingUp, Monitor, BookOpen, Feather } from 'lucide-react';

const ICON_MAP: Record<string, React.ElementType> = {
  'calculator': Calculator,
  'briefcase': Briefcase,
  'trending-up': TrendingUp,
  'monitor': Monitor,
  'book-open': BookOpen,
  'feather': Feather
};

interface ChapterListProps {
  subject: Subject;
  onSelectChapter: (chapter: Chapter) => void;
  onBack: () => void;
}

const ChapterList: React.FC<ChapterListProps> = ({ subject, onSelectChapter, onBack }) => {
  const SubjectIcon = ICON_MAP[subject.iconKey] || BookOpen;

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto animate-fade-in">
      <button 
        onClick={onBack}
        className="mb-6 text-slate-400 hover:text-amber-400 text-sm flex items-center transition-colors px-2 py-1"
      >
        &larr; Back to Subjects
      </button>

      <div className="mb-8 border-b border-slate-700 pb-4 flex items-center space-x-4 px-2">
        <div className="p-3 bg-slate-800 rounded-lg border border-slate-700">
           <SubjectIcon className={`w-8 h-8 ${subject.color}`} />
        </div>
        <div>
           <h2 className={`text-2xl md:text-4xl font-serif font-bold ${subject.color} mb-1`}>{subject.name}</h2>
           <p className="text-slate-400 text-xs md:text-base">Subject Code: {subject.code} • 1st PUC Karnataka Board</p>
        </div>
      </div>

      <div className="grid gap-3 md:gap-4">
        {subject.chapters.map((chapter, index) => (
          <button
            key={chapter.id}
            onClick={() => onSelectChapter(chapter)}
            className="group flex items-center justify-between p-4 md:p-5 bg-[#1e293b] border border-slate-700 rounded-lg hover:border-amber-400/50 hover:bg-[#253248] transition-all duration-300 text-left shadow-sm hover:shadow-md active:scale-[0.99]"
          >
            <div className="flex items-center space-x-4">
              <div className="flex-shrink-0 w-8 h-8 md:w-10 md:h-10 rounded-full bg-slate-900 flex items-center justify-center border border-slate-700 group-hover:border-amber-400 group-hover:text-amber-400 transition-colors font-mono font-bold text-slate-400 text-sm md:text-base">
                {index + 1}
              </div>
              <div>
                <h3 className="text-base md:text-lg font-semibold text-slate-100 group-hover:text-white line-clamp-1 md:line-clamp-none">{chapter.title}</h3>
                <p className="text-[10px] md:text-xs text-slate-500 uppercase tracking-wider mt-1 group-hover:text-slate-400">Chapter Guide</p>
              </div>
            </div>
            <ChevronRight className="text-slate-600 group-hover:text-amber-400 transition-transform group-hover:translate-x-1 w-5 h-5 md:w-6 md:h-6" />
          </button>
        ))}
      </div>
    </div>
  );
};

export default ChapterList;