import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Subject, Chapter, ContentType, SubjectId } from '../types';
import { fetchStudyContent } from '../services/geminiService';
import { 
  BookOpen, 
  ListChecks, 
  PenTool, 
  FileText, 
  Calculator, 
  History, 
  Lightbulb, 
  Printer, 
  RefreshCw,
  Timer,
  Eye,
  EyeOff,
  Feather,
  Briefcase,
  TrendingUp,
  Monitor,
  AlertTriangle,
  CheckCircle2,
  Terminal
} from 'lucide-react';

// Icon Map for headers if needed, similar to App.tsx
const ICON_MAP: Record<string, React.ElementType> = {
  'calculator': Calculator,
  'briefcase': Briefcase,
  'trending-up': TrendingUp,
  'monitor': Monitor,
  'book-open': BookOpen,
  'feather': Feather
};

interface ContentGeneratorProps {
  subject: Subject;
  chapter: Chapter;
  onBack: () => void;
}

const TABS = [
  { id: ContentType.CONCEPTS, icon: BookOpen, label: 'Concepts' },
  { id: ContentType.MCQ, icon: ListChecks, label: 'Objective' },
  { id: ContentType.SHORT_ANSWERS, icon: PenTool, label: 'Short' },
  { id: ContentType.LONG_ANSWERS, icon: FileText, label: 'Long' },
  { id: ContentType.PRACTICAL, icon: Calculator, label: 'Practical' },
  { id: ContentType.PREVIOUS_PAPERS, icon: History, label: 'Papers' },
  { id: ContentType.TIPS, icon: Lightbulb, label: 'Tips' },
  { id: ContentType.EXAM_SIMULATION, icon: Timer, label: 'Exam' },
];

const ContentGenerator: React.FC<ContentGeneratorProps> = ({ subject, chapter, onBack }) => {
  const [activeTab, setActiveTab] = useState<ContentType>(ContentType.CONCEPTS);
  const [content, setContent] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [streaming, setStreaming] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // Exam Mode State
  const [examTimeLeft, setExamTimeLeft] = useState<number>(45 * 60); // 45 minutes
  const [isExamActive, setIsExamActive] = useState<boolean>(false);
  const [showExamAnswers, setShowExamAnswers] = useState<boolean>(false);
  const timerRef = useRef<number | null>(null);
  const contentAreaRef = useRef<HTMLDivElement>(null);

  const SubjectIcon = ICON_MAP[subject.iconKey] || BookOpen;

  const loadContent = async (type: ContentType, forceRefresh = false) => {
    // Check localStorage for persistent caching
    const cacheKey = `mae_cache_${subject.id}_${chapter.id}_${type}`;
    const cached = localStorage.getItem(cacheKey);

    if (cached && !forceRefresh) {
      setContent(cached);
      handleTabChangeEffects(type, cached);
      return;
    }

    setLoading(true);
    setStreaming(false);
    setError(null);
    setContent('');
    
    // Reset exam state if generating new exam
    if (type === ContentType.EXAM_SIMULATION) {
      setExamTimeLeft(45 * 60);
      setIsExamActive(true);
      setShowExamAnswers(false);
    }

    try {
      // Pass a callback to handle streaming updates
      const result = await fetchStudyContent(
        subject.id, 
        subject.name, 
        chapter.title, 
        type, 
        (streamedText) => {
          setContent(streamedText);
          setStreaming(true);
        }
      );
      
      setContent(result);
      localStorage.setItem(cacheKey, result);
      handleTabChangeEffects(type, result);
    } catch (err) {
      setError("Failed to load content. Please check your connection.");
    } finally {
      setLoading(false);
      setStreaming(false);
    }
  };

  const handleTabChangeEffects = (type: ContentType, loadedContent: string) => {
    // Scroll to top when tab changes
    if (contentAreaRef.current) {
        contentAreaRef.current.scrollTop = 0;
    }

    if (type === ContentType.EXAM_SIMULATION) {
      setIsExamActive(true);
      // Ensure timer starts
      if (timerRef.current) window.clearInterval(timerRef.current);
      timerRef.current = window.setInterval(() => {
        setExamTimeLeft((prev) => {
          if (prev <= 1) {
            if (timerRef.current) window.clearInterval(timerRef.current);
            setShowExamAnswers(true); // Auto reveal on timeout
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setIsExamActive(false);
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  useEffect(() => {
    loadContent(activeTab);
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab]);

  const handlePrint = () => {
    window.print();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Logic to hide answers in exam mode
  const getDisplayContent = () => {
    // Regex to find the separator, robust against markdown code blocks or whitespace
    const separatorRegex = /[`]*\s*\|{3}HIDDEN_SEPARATOR\|{3}\s*[`]*/i;
    
    if (activeTab === ContentType.EXAM_SIMULATION && content) {
      const match = content.match(separatorRegex);
      
      if (match) {
        const separatorIndex = match.index!;
        const part1 = content.substring(0, separatorIndex);
        const part2 = content.substring(separatorIndex + match[0].length);
        
        if (!showExamAnswers) {
          return part1;
        } else {
          return part1 + "\n\n---\n\n" + part2;
        }
      }
    }
    return content;
  };

  return (
    <div className="flex flex-col h-full bg-[#0f172a]">
      {/* Top Bar */}
      <div className="bg-[#1e293b] border-b border-slate-700 p-2 md:p-4 sticky top-0 z-10 no-print shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between max-w-7xl mx-auto w-full gap-3 md:gap-0">
          
          {/* Header Left: Icon + Titles */}
          <div className="flex items-center space-x-3 overflow-hidden">
             <div className={`flex-shrink-0 p-2 rounded-lg bg-slate-800 border border-slate-700 hidden md:block`}>
                <SubjectIcon className={`w-5 h-5 ${subject.color}`} />
             </div>
             <div className="min-w-0 flex-1">
                <button onClick={onBack} className="text-slate-400 hover:text-amber-400 text-[10px] md:text-xs uppercase tracking-widest mb-0.5 md:mb-1 block transition-colors truncate">
                  &larr; {subject.name}
                </button>
                <h2 className="text-base md:text-2xl font-serif font-bold text-slate-100 truncate">
                  {chapter.title}
                </h2>
             </div>
          </div>
          
          {/* Header Right: Controls */}
          <div className="flex items-center justify-between md:justify-end space-x-2 w-full md:w-auto">
             {activeTab === ContentType.EXAM_SIMULATION && (
               <div className={`flex items-center space-x-2 px-3 py-1.5 md:py-2 rounded-md font-mono font-bold text-sm md:text-base whitespace-nowrap ${examTimeLeft < 300 ? 'bg-red-900/50 text-red-400 animate-pulse' : 'bg-slate-800 text-amber-400'}`}>
                 <Timer size={16} />
                 <span>{formatTime(examTimeLeft)}</span>
               </div>
             )}
             
             <div className="flex space-x-2">
               <button 
                  onClick={() => loadContent(activeTab, true)}
                  className="p-2 text-slate-400 hover:text-amber-400 bg-slate-800 rounded-md border border-slate-700 hover:bg-slate-700 transition-colors"
                  title="Regenerate with AI"
                >
                  <RefreshCw size={18} />
                </button>
                <button 
                  onClick={handlePrint}
                  className="flex items-center space-x-2 px-3 md:px-4 py-1.5 md:py-2 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold rounded-md transition-colors text-sm whitespace-nowrap"
                >
                  <Printer size={16} />
                  <span className="hidden sm:inline">PDF / Print</span>
                  <span className="sm:hidden">PDF</span>
                </button>
             </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 mt-3 md:mt-4 overflow-x-auto pb-1 max-w-7xl mx-auto w-full scrollbar-hide snap-x">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`
                  flex items-center space-x-2 px-3 md:px-4 py-2 rounded-t-lg text-xs md:text-sm font-medium transition-all whitespace-nowrap select-none snap-start
                  ${isActive 
                    ? 'bg-[#0f172a] text-amber-400 border-t-2 border-amber-400 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'}
                `}
              >
                <Icon size={14} className="md:w-4 md:h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content Area */}
      <div ref={contentAreaRef} className="flex-1 overflow-y-auto p-4 md:p-8 print-content bg-[#0f172a] scroll-smooth">
        <div className="max-w-5xl mx-auto bg-[#1e293b] min-h-[500px] p-4 md:p-12 rounded-b-lg shadow-xl border border-slate-700 print:border-none print:shadow-none print:bg-white print:text-black">
          
          {/* Header for Print View */}
          <div className="hidden print:block mb-8 border-b-2 border-black pb-4">
             <h1 className="text-3xl font-bold">{subject.name} - {chapter.title}</h1>
             <h2 className="text-xl mt-2">{activeTab}</h2>
             <p className="text-sm mt-4 text-gray-500">Mastering Academic Excellence - 1st PUC Study Guide</p>
          </div>

          {loading && !streaming ? (
            <div className="flex flex-col items-center justify-center h-64 space-y-4">
              <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-slate-300 font-serif text-xl animate-pulse text-center px-4">Consulting the Academic Board...</p>
              <p className="text-slate-500 text-sm text-center px-4">Retrieving latest blueprint and scheme of valuation for {subject.name}...</p>
            </div>
          ) : error ? (
             <div className="text-center p-12 border border-red-900/50 bg-red-900/10 rounded-lg">
                <p className="text-red-400 text-lg mb-4">{error}</p>
                <button onClick={() => loadContent(activeTab)} className="text-slate-300 underline hover:text-white">Try Again</button>
             </div>
          ) : (
            <>
              <ReactMarkdown 
                className="prose prose-sm md:prose-base prose-invert prose-amber max-w-none print:prose-black 
                  prose-headings:font-serif prose-headings:font-bold 
                  prose-h1:text-2xl md:prose-h1:text-3xl prose-h1:text-amber-500 
                  prose-h2:text-xl md:prose-h2:text-2xl prose-h2:text-amber-400 prose-h2:border-b prose-h2:border-slate-700 prose-h2:pb-2
                  prose-h3:text-lg md:prose-h3:text-xl prose-h3:text-amber-100
                  prose-strong:text-amber-200
                  prose-table:border-collapse prose-th:border prose-th:border-slate-600 prose-th:bg-slate-800 prose-th:p-2 prose-th:text-amber-400
                  prose-td:border prose-td:border-slate-700 prose-td:p-2
                  print:prose-headings:text-black print:prose-h2:border-gray-300 print:prose-th:bg-gray-100 print:prose-th:text-black print:prose-td:border-gray-300"
                remarkPlugins={[remarkGfm]}
                components={{
                  table: ({node, ...props}) => <div className="overflow-x-auto my-8 border border-slate-700 rounded-lg"><table className="w-full text-left text-sm border-collapse min-w-[600px]" {...props} /></div>,
                  th: ({node, ...props}) => <th className="bg-slate-800 border border-slate-600 p-3 text-amber-400 font-bold whitespace-nowrap" {...props} />,
                  td: ({node, ...props}) => <td className="border border-slate-700 p-3" {...props} />,
                  
                  // Enhanced Blockquote: Auto-detects "Mistake", "Key Term" etc. for smart styling
                  blockquote: ({node, ...props}) => {
                    // Extract text content to determine style
                    let textContent = '';
                    // Robust extraction of text from children
                    React.Children.forEach(props.children, child => {
                        if (React.isValidElement(child) && child.props.children) {
                             if (typeof child.props.children === 'string') textContent += child.props.children;
                             else if (Array.isArray(child.props.children)) textContent += child.props.children.join('');
                        }
                    });
                    textContent = textContent.toLowerCase();

                    const isWarning = textContent.includes('mistake') || textContent.includes('avoid') || textContent.includes('pitfall') || textContent.includes('error');
                    const isKey = textContent.includes('key') || textContent.includes('valuation') || textContent.includes('glossary') || textContent.includes('term');
                    
                    let borderColor = 'border-amber-500';
                    let bgColor = 'bg-amber-900/10';
                    let Icon = Lightbulb;
                    let iconBg = 'bg-amber-500';
                    
                    if (isWarning) {
                        borderColor = 'border-rose-500';
                        bgColor = 'bg-rose-900/10';
                        Icon = AlertTriangle;
                        iconBg = 'bg-rose-500';
                    } else if (isKey) {
                        borderColor = 'border-emerald-500';
                        bgColor = 'bg-emerald-900/10';
                        Icon = CheckCircle2;
                        iconBg = 'bg-emerald-500';
                    }

                    return (
                        <blockquote className={`border-l-4 ${borderColor} ${bgColor} px-6 py-4 rounded-r-lg my-6 text-slate-300 relative shadow-lg`}>
                            <div className={`absolute -left-3 -top-3 ${iconBg} rounded-full p-1 text-slate-900 shadow-md`}>
                                <Icon size={14} strokeWidth={3} />
                            </div>
                            <div className="italic leading-relaxed">
                                {props.children}
                            </div>
                        </blockquote>
                    );
                  },

                  // Enhanced Code Block container (Pre) - Terminal Style
                  pre: ({node, ...props}) => (
                    <div className="my-8 relative group rounded-lg overflow-hidden border border-slate-700 shadow-2xl bg-[#0b1120]">
                      <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
                         <div className="flex space-x-1.5">
                            <div className="w-3 h-3 rounded-full bg-red-500/80 hover:bg-red-500 transition-colors"></div>
                            <div className="w-3 h-3 rounded-full bg-yellow-500/80 hover:bg-yellow-500 transition-colors"></div>
                            <div className="w-3 h-3 rounded-full bg-green-500/80 hover:bg-green-500 transition-colors"></div>
                         </div>
                         <div className="flex items-center text-xs text-slate-400 font-mono select-none">
                           <Terminal size={12} className="mr-1.5" />
                           <span>bash</span>
                         </div>
                      </div>
                      <pre className="p-4 overflow-x-auto font-mono text-sm leading-relaxed text-slate-300 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-transparent" {...props} />
                    </div>
                  ),

                  // Inline vs Block Code logic
                  code: ({node, className, children, ...props}: any) => {
                    const match = /language-(\w+)/.exec(className || '');
                    // If it has a language class, it's likely a block inside the pre component above
                    if (match) {
                        return <code className={`font-mono text-amber-100 ${className}`} {...props}>{children}</code>
                    }
                    // Otherwise it's inline code
                    return <code className="bg-slate-800 text-amber-300 px-1.5 py-0.5 rounded font-mono text-sm border border-slate-700/50 shadow-sm" {...props}>{children}</code>
                  }
                }}
              >
                {getDisplayContent()}
              </ReactMarkdown>
              
              {activeTab === ContentType.EXAM_SIMULATION && (
                <div className="mt-8 flex justify-center no-print">
                   <button 
                    onClick={() => setShowExamAnswers(!showExamAnswers)}
                    className="flex items-center space-x-2 px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-full transition-colors font-semibold shadow-lg hover:shadow-xl hover:scale-105 transform duration-200 active:scale-95"
                   >
                     {showExamAnswers ? <EyeOff size={18}/> : <Eye size={18}/>}
                     <span>{showExamAnswers ? 'Hide Answer Key' : 'Reveal Answer Key'}</span>
                   </button>
                </div>
              )}
            </>
          )}
          
          {!loading && !error && !streaming && (
             <div className="mt-12 pt-8 border-t border-slate-700 text-center text-slate-500 text-sm print:hidden">
                <p>Content generated specifically for Karnataka PU Board syllabus (2024-25).</p>
                <p className="mt-1">Review marking scheme carefully before exam.</p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContentGenerator;