export enum SubjectId {
  BUSINESS_STUDIES = 'BUSINESS_STUDIES',
  ACCOUNTANCY = 'ACCOUNTANCY',
  ECONOMICS = 'ECONOMICS',
  COMPUTER_SCIENCE = 'COMPUTER_SCIENCE',
  ENGLISH = 'ENGLISH',
  KANNADA = 'KANNADA'
}

export enum ContentType {
  CONCEPTS = 'Concepts',
  MCQ = 'MCQs & Objective',
  SHORT_ANSWERS = 'Short Answers (3-5 Marks)',
  LONG_ANSWERS = 'Long Answers (6-10 Marks)',
  PRACTICAL = 'Practical Problems',
  PREVIOUS_PAPERS = 'Previous Papers & Solutions',
  TIPS = 'Exam Tips & Common Mistakes',
  EXAM_SIMULATION = 'Mock Exam Mode'
}

export interface Chapter {
  id: string;
  title: string;
}

export interface Subject {
  id: SubjectId;
  name: string;
  code: string;
  chapters: Chapter[];
  color: string;
  iconKey: string;
}

export interface GeneratedContent {
  title: string;
  body: string; // Markdown formatted string
  timestamp: number;
}